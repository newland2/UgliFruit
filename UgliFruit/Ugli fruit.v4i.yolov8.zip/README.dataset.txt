# Ugli fruit > 2023-09-30 8:29pm
https://universe.roboflow.com/eli-newland/ugli-fruit

Provided by a Roboflow user
License: CC BY 4.0

